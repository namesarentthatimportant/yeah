//---//

-- /// LIMITED VALUE DECREASER // --
-- // THIS IS JUST A TOOL TO PROJECT ITEMS THAT YOU ALREADY OWN, NOTE THAT WE AS THE PUBLISHERS TAKE NO BLAME FOR WHAT YOU DO WITH THIS // --
-- // HAVE FUN /// --

made by lucif3r and xfzq

v2
- crashing fixed
- better layout
- item rap updates faster

-- !! IMPORTANT: OPEN A ROBLOX INSTANCE FOR IT TO PROPERLY RUN AND TO AVOID GETTING BLACKLISTED !! --

//---//